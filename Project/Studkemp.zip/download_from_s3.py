import tempfile
import boto3
import os

S3_ENDPOINT = os.environ.get("S3_ENDPOINT")
S3_ACCESS_KEY = os.environ.get("S3_ACCESS_KEY")
S3_SECRET_KEY = os.environ.get("S3_SECRET_KEY")
S3_BUCKET = os.environ.get("S3_BUCKET")
S3_PREFIX = os.environ.get("S3_PREFIX")

import pdfplumber
from langchain.schema import Document
import os

def load_and_index_documents(file_paths):
    docs = []
    for path in file_paths:
        if not os.path.isfile(path):
            continue

        if path.lower().endswith(".pdf"):
            try:
                with pdfplumber.open(path) as pdf:
                    for i, page in enumerate(pdf.pages):
                        text = page.extract_text()
                        if text and text.strip():
                            docs.append(
                                Document(
                                    page_content=text.strip(),
                                    metadata={"source": os.path.basename(path), "page": i}
                                )
                            )
            except Exception as e:
                print(f"Ошибка обработки PDF {path}: {e}")

    return docs

def download_from_s3():
    s3 = boto3.client(
        's3',
        endpoint_url=S3_ENDPOINT,
        aws_access_key_id=S3_ACCESS_KEY,
        aws_secret_access_key=S3_SECRET_KEY,
        region_name="ru-central1"
    )
    try:
        objects = s3.list_objects_v2(Bucket=S3_BUCKET, Prefix=S3_PREFIX)
        print(objects)
    except Exception as e:
        print(f"Ошибка подключения: {e}")
        return None

    if 'Contents' in objects:
        print("Файлы в бакете:")
        for obj in objects['Contents']:
            print("-", obj['Key'])

    if 'Contents' not in objects:
        return load_and_index_documents([])

    local_files = []
    with tempfile.TemporaryDirectory() as tmpdir:
        for obj in objects['Contents']:
            key = obj.get('Key')
            if not key or not isinstance(key, str) or key.endswith('/'):
                continue

            size = obj.get('Size', 0)
            if size == 0:
                continue

            local_path = os.path.join(tmpdir, os.path.basename(key))
            try:
                s3.download_file(S3_BUCKET, key, local_path)
                if os.path.getsize(local_path) == 0:
                    continue
                local_files.append(local_path)
            except Exception as e:
                print(f"Ошибка скачивания {key}: {e}")
                continue

        return load_and_index_documents(local_files)